package com.iesebre;

import java.util.Scanner;

public class Main {

    public static Scanner sc = new Scanner(System.in);


    public static void main(String[] args) {

        System.out.println("1. Conversar.");
        System.out.println("2. Mostrar conversa.");
        System.out.println("3. Sortir del programa.");

        String[] conversa;
        int quants;
        quants = Integer.parseInt(sc.nextLine());

        while (quants > 3 || quants<0){

            if (true) {
                System.out.println("Valor incorrecte. Torna-ho a provar.");
                quants = Integer.parseInt(sc.nextLine());
            }
            else {
                break;
            }
        }


        conversa = new String[quants];

        switch (quants) {
            case 1:
                boolean finish = false;
                System.out.println("Amb qui vols conversar?");
                System.out.println(" - Persona");
                System.out.println(" - Animal");
                System.out.println(" - Extraterrestre");
                System.out.print("Opció: ");

                do {
                    // Escollir amb qui volem conversar

                    switch (sc.nextLine()) {
                        case "Persona" -> {
                            Person person = new Person();
                             conversa[quants] = person.talking();
                        }
                        case "Animal" -> {
                            /*Animal animal = new Animal();
                            conveses[quants] = animal.talking();*/
                            System.out.println("si");
                        }
                        /*case "Aliem":
                               Alien extraterrestre = new Alien();
                                conveses[quants] = Alien.talking();
                                break;*/

                    }


                } while (!finish);

                case 2:
                    System.out.println(conversa);
                    break;

                case 3:
                    return;

            default:
                System.out.println("Opcio incorrecta. Torna-ho a intentar!!");

        }
    }
}