package com.iesebre;

import java.util.Random;

import static com.iesebre.Main.*;

public class Person {
    // Constructor
    void Person() {
    }

    public String talking() {
        boolean[] ordre;
        ordre = new boolean[7];
        System.out.println("Hola, que tal!");
        System.out.println("Tria una pregunta les has de respondre totes");


        int pregunta;

        String sexe = "";

        String nom = "";

        String esport1 = "";

        int num1 = 1;
        int num2 = 0;



        String jugada1;
        double jugada2;
        int puntuacio1 =0;
        int puntuacio2 = 0;
        String win = "";

        String conversa ="";
        while (true) {
            System.out.println("Escull que li vols preguntar:");
            System.out.println("1. Quin tipus de persona ets?");
            System.out.println("2.Quin esport t'agrada?");
            System.out.println("3.Quin és el teu número favorit entre 0 i ...");
            System.out.println("4.Sabries llista tots els nombres parells resultants de la multiplicació, entre el valor enter\n" +
                    "de a i b, on el valor de a creixerà fins b, b decreixerà fins a ?");
            System.out.println("5.Juguem a pedra paper i tisora?");
            System.out.println("6.Posa-li un nom");
            System.out.println("7.Pots recordar-me la nostra conversa?");
            System.out.println("8.Sortida de l'aplicació");

            pregunta = sc.nextInt();

            while (pregunta > 8 || pregunta<0){

                if (pregunta > 8 || pregunta<0) {

                    System.out.println("Valor incorrecte. Torna-ho a provar.");

                    pregunta = (byte) Integer.parseInt(sc.nextLine());

                } else  {

                    break;

                }
            }

            switch (pregunta) {

                case 1 -> {
                    System.out.println("Quin tipus de persona ets?");

                    int resposta;
                    resposta = Integer.parseInt(sc.nextLine());
                    while (resposta > 100 || resposta<1) {

                        if (true) {
                            System.out.println("Valor incorrecte. Torna-ho a provar.");
                            resposta = Integer.parseInt(sc.nextLine());
                        }
                        else  {
                            break;
                        }
                    }

                    int n1 = 2;
                    int n2 = 3;
                    sc.nextLine();

                    if ((resposta % n1 == 0) && (resposta % n2 != 0)) {
                        System.out.println("Home");
                        sexe = "Home";
                    } else if ((resposta % n1 != 0) && (resposta % n2 == 0)) {
                        System.out.println("Dona");
                        sexe = "Dona";
                    } else {
                        System.out.println("No binari");
                        sexe = "No binari";

                    }

                    ordre[0] = true;
                }



                case 2 -> {
                    if (ordre[0] ||ordre[1]) {
                    System.out.println("Quin esport t'agrada?");
                    System.out.println("1.Futbol");
                    System.out.println("2.Bàsquet");
                    System.out.println("3.Tenis");
                    System.out.println("4.Pàdel");
                    System.out.println("5.Natació");
                    System.out.println("6.Petanca");
                    System.out.println("7.Patinatge");
                    System.out.println("8.Twirling");
                    System.out.println("9.Esquí");
                    System.out.println("10.eSports");

                    int esport = sc.nextInt();

                        esport = Integer.parseInt(sc.nextLine());
                        while (esport > 10 || esport<1){
                            if (true) {
                            System.out.println("Valor incorrecte. Torna-ho a provar.");
                            esport = Integer.parseInt(sc.nextLine());

                            }else  {
                            break;

                            }
                        }

                    do {

                    switch (esport) {
                        case 1 -> {
                            System.out.println("Futbol");
                            esport1 = "Futbol";
                            ordre[1] = true;
                        }
                        case 2 -> {
                            System.out.println("Bàsquet");
                            esport1 = "Bàquet";
                            ordre[1] = true;
                        }
                        case 3 -> {
                            System.out.println("Tenis");
                            esport1 = "Tenis";
                            ordre[1] = true;
                        }
                        case 4 -> {
                            System.out.println("Pàdel");
                            esport1 = "Pàdel";
                            ordre[1] = true;
                        }
                        case 5 -> {
                            System.out.println("Natació");
                            esport1 = "Natació";
                        }
                        case 6 -> {
                            System.out.println("Petanca");
                            esport1 = "Petanca";
                            ordre[1] = true;
                        }
                        case 7 -> {
                            System.out.println("Patinatge");
                            esport1 = "Patinatge";
                            ordre[1] = true;
                        }
                        case 8 -> {
                            System.out.println("Twirling");
                            esport1 = "Twirling";
                            ordre[1] = true;
                        }
                        case 9 -> {
                            System.out.println("Esquí");
                            esport1 = "Esquí";
                            ordre[1] = true;
                        }
                        case 10 -> {
                            System.out.println("eSports");
                            esport1 = "eSports";
                            ordre[1] = true;
                        }
                        default -> {
                            System.out.println("Valor incorrecte. Torna-ho a intentar");
                            ordre[1] = false;
                        }
                    }
                    }
                    while (ordre[1] = false);
                    }
                }

                case 3 -> {
                    System.out.println("Quin és el teu número favorit entre 0 i ...?");
                    if (ordre[1] ||ordre[2]) {
                        System.out.println("donam un rang");

                        num2 = sc.nextInt();

                        num2 = Integer.parseInt(sc.nextLine());
                        while (num2>0){
                            if (true) {
                                System.out.println("Valor incorrecte. Torna-ho a provar.");
                                num2 = Integer.parseInt(sc.nextLine());
                            }else {
                                break;
                            }
                        }

                        num2 = (num2 - (num2 - num1) / 2);
                        while (num2 > num1) {
                            System.out.print("" + (num1 -1)+ " ");
                            num1++;
                        }
                        System.out.println("...He triat el " + (num2-1) + "!");

                        ordre[2] = true;
                    }
                }

                case 4 -> {

                    if (ordre[2] || ordre[3]) {

                        System.out.println("Escull 2 nombres");

                        int a = sc.nextInt();

                        int b = sc.nextInt();

                        for (int i = a; i <= b; i++) {
                            System.out.println();
                            for (int j = b; j >= 1; j--) {
                                if ((i * j) % 2 == 0) System.out.print(i * j + "  ");
                            }
                        }
                        System.out.println();

                        ordre[3]=true;
                    }
                }

                case 5 -> {

                        if (ordre[3] && !ordre[4]) {

                            while (puntuacio1 < 5 || puntuacio2 < 5) {

                                System.out.println("digues pedra ,paper o tisora");

                                jugada1 = sc.nextLine();
                                jugada2 = new Random().nextInt(3 + 1);
                                System.out.println(jugada2);

                                //1 es paper 2 es pedra 3 es tisores

                                if ((jugada1.equals("pedra") && jugada2 == 1) || (jugada1.equals("tisora") && jugada2 == 2) || (jugada1.equals("paper") && jugada2 == 3)) {
                                    puntuacio1++;
                                    System.out.println("Jugador1");
                                } else {
                                    if ((jugada2 == 2 && jugada1.equals("paper")) || (jugada2 == 3 && jugada1.equals("pedra")) || (jugada2 == 1 && jugada1.equals("tisora"))) {
                                        puntuacio2++;
                                        System.out.println("Jugador2");

                                    } else if ((jugada1.equals("pedra") && jugada2 == 2) || (jugada1.equals("tisora") && jugada2 == 3) || (jugada1.equals("paper") && jugada2 == 2)) {
                                        puntuacio1++;
                                        puntuacio2++;
                                        System.out.println("EMPAT");
                                    }
                                }
                                if (puntuacio1 == 5) {
                                    System.out.println("Has guanyat");
                                    win = ("tu");
                                    ordre[4]=true;
                                    break;

                                }
                                else if (puntuacio2 == 5) {
                                    System.out.println("Has perdut");
                                    win = ("PC");
                                    ordre[4]=true;
                                    break;
                                }
                            }

                        }
                        else {
                            System.out.println("Has de seguir les opcions en ordre, sense que es repeteixin");
                        }

                }

                case 6 -> {
                    if (ordre[4] ||ordre[5]) {
                        System.out.println("Quin és el meu nom?");

                        sc.nextLine();
                        nom = sc.nextLine();
                        while (nom.trim().length()==0){
                            if (true) {
                                System.out.println("Valor incorrecte. Torna-ho a provar.");
                                nom = sc.nextLine();
                            }
                            else if (false){
                                System.out.println("Gracies,m'agrada molt el nom de " + nom);
                                ordre[5] = true;
                            }

                        }
                    }
                    else {
                        System.out.println("Has de seguir les opcions en ordre i sense repetir. Torna-ho a intentar!!");
                        break;
                    }
                }

                case 7 -> {
                    if (ordre[5] ||ordre[6]) {
                    System.out.println("El meu nom és " + nom + " sóc " + sexe + " l'esport que a mi m'agrada és " + esport1 + " el meu nombre preferit és " + (num2 - 1) + " ha guanyat " + win);
                    ordre[6] = true;
                    }
                }

                case 8 -> {
                    System.out.println("Segur que vols sortir?");

                    if (ordre[6] = true) {
                        return conversa;

                    }
                    else{
                        System.out.println("Encara tens respostes per fer. Tens que fer-les en ordre");

                    }

                }
            }

        }
    }
}



