package com.iesebre;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Scanner;
import java.lang.String;

public class Alien {


        Scanner sc = new Scanner(System.in);

          String nombre;
          String transporte;
          String tipo;
          String ganador;
          String resultado;

          boolean acabado;

          boolean[] preguntas = new boolean[7];
          boolean salir1;
          boolean salir2;

    public Alien() {
        this.acabado = false;
        this.salir1 = false;
        this.salir2 = false;
    }

    String talking() {



        do {
            System.out.println("Cuestionario:");
            System.out.println("1.Tipo de alien");
            System.out.println("2.Como te desplazas?");
            System.out.println("3.Cual es tu numero favorito?");
            System.out.println("4.Sabrias listar todos los numeros depues de la coma...");
            System.out.println("5.Juegas a los barquitos?");
            System.out.println("6.Ponle un nombre");
            System.out.println("7.Te acuerda de las conversacion?");
            System.out.println("8.Salir");
            int opcion = sc.nextInt();

            switch (opcion) {

                //Ejercicio 1


                case 1:

                    System.out.println("Elige el numero que mas prefieras:");
                    tipus(sc.nextFloat());
                    break;

                //Ejercicio 2

                case 2:

                    System.out.print("Escribe un float entre (0 y 1):");
                    transporte(sc.nextFloat());
                    break;

                //Ejercicio 3

                case 3:

                    System.out.println("Escribe un numero positivo: ");
                    favorit(sc.nextFloat());
                    break;

                //Ejercicio 4

                case 4:

                    System.out.println("Dime 2 numeros:");
                    float Numero1 = sc.nextFloat();
                    float Numero2 = sc.nextFloat();
                    calcul(sc.nextFloat(), sc.nextFloat() );
                    break;

                //Ejercicio 5

                case 5:

                    System.out.println("Vamos a jugar a un juego....");
                    System.out.println("Introduce un numero entre 0 y 4");

                    joc(sc.nextLine());
                    break;

                //Ejercicio 6
                case 6:

                    System.out.println("Elige mi nombre:  " );
                    nom(sc.nextLine());
                    break;

                case 7:

                    System.out.println("Puedes recordar nuestra conversacion?");
                    printConversa();
                    break;

                case 8:

                    fiConversa();
                    break;

            }


        } while (!salir2);

        return "";
    }

    String tipus(float numero) {

        sc.nextLine();
        numero = numero % 1; //sobrante de una division
        numero = numero * 10; // sirve para mover la coma hacia un lugar
        numero = Math.round(numero); //con esto redondeamos el numero dado por la operacion anterior.

        // System.out.println(numero);
        if (numero > 5) tipo = "Pau";
        if (numero < 5) tipo = "Assasi";
        if (numero == 5.0) tipo = "Sucubo";

        System.out.println("El alien es tipo: " + tipo); //con el "+", es usado para concatenar textos con variables
        preguntas[0] = true;

        return tipo;
    }

    String transporte(float random) {

        if (preguntas[0] == true) {
            //Scanner sc = new Scanner(System.in);

            random = sc.nextFloat();
            sc.nextLine();
            random = random % 1;
            random = random * 10;

            if (random == 0) {

                System.out.print("Mi metodo de transporte es: ");
                System.out.println("Nave");
                transporte = "nave";
            } else if (random == 1) {
                System.out.print("Mi metodo de transporte es: ");
                System.out.println("Cohete");
                transporte = "Cohete";
            } else if (random == 2) {
                System.out.print("Mi metodo de transporte es: ");
                System.out.println("Propulsor");
                transporte = "Propulsor";
            } else if (random == 3) {
                System.out.print("Mi metodo de transporte es: ");
                System.out.println("Teletransporte");
                transporte = "Teletransporte";
            } else if (random == 4) {
                System.out.print("Mi metodo de transporte es: ");
                System.out.println("Coche");
                transporte = "Coche";
            } else if (random == 5) {
                System.out.print("Mi metodo de transporte es: ");
                System.out.println("Portales");
                transporte = "Portales";
            } else if (random == 6) {
                System.out.print("Mi metodo de transporte es: ");
                System.out.println("Velocidad de la luz");
                transporte = "Velocidad de la luz";
            } else if (random == 7) {
                System.out.print("Mi metodo de transporte es: ");
                System.out.println("Traje de ironman");
                transporte = "Traje de ironman";
            } else if (random == 8) {
                System.out.print("Mi metodo de transporte es: ");
                System.out.println("Tanque Sovietico");
                transporte = "Tanque Sovietico";
            } else if (random == 9) {
                System.out.print("Mi metodo de transporte es: ");
                System.out.println("F-35 Lightning II");
                transporte = "F-35 Lightning II";
            } else if (random == 10) {
                System.out.print("Mi metodo de transporte es: ");
                System.out.println("Triciclo");
                transporte = "Triciclo";
            }

            preguntas[1] = true;

        } else {
            System.out.println("Tienes que responder la anterior pregunta");
        }
        return transporte;
    }
     int favorit(float numeroFav ){

         if (preguntas[1] == true) {

             numeroFav = sc.nextFloat();
             sc.nextLine();
             numeroFav = numeroFav / 2;

             float i = 0;
             while (i <= numeroFav) {
                 System.out.printf("%.1f ", i);
                 i += 0.1;
                 System.out.println("");
             }
             float resultado = i;
             System.out.print("Mi numero favorito es: ");
             System.out.printf("%.0f", resultado);
             System.out.println("");
             preguntas[2] = true;
         } else {
             System.out.println("Tienes que hacerme la pregunta anterior");
         }
         return (int) numeroFav;
     }

    String calcul(float numero1, float numero2) {

        if (preguntas[2] == true) {

            System.out.println("Numero1:");
            numero1 = sc.nextFloat();
            sc.nextLine();
            System.out.println("Numero 2:");
            numero2 = sc.nextFloat();
            sc.nextLine();

            System.out.println();
            for (float i = numero1; i <= (float) ((numero1 + numero2) / 2.0); i = (float) (i + 0.1)) {
                if (i % 2 == 1) System.out.printf(resultado = "%2.1f ", i);
            }
            System.out.println();
            preguntas[3] = true;

        } else {
            System.out.println("Tienes que hacerme la pregunta anterior");
        }
        return resultado;
    }

    String joc(String s){

        if (preguntas[3] == true) {


            double NumeroRandomD = Math.random() * 4;
            BigDecimal UnDecimal2 = new BigDecimal(NumeroRandomD);
            BigDecimal Tallat = UnDecimal2.setScale(1, RoundingMode.DOWN);
            NumeroRandomD = Tallat.doubleValue();
            float NumeroRandomF = (float) NumeroRandomD;
            //Aqui declrao el Float sin valor, los intentos que nos indica el ejercicio y el bloeano que nos ayuda a acabar la partida.
            float NumeroPersona;
            int intentos = 10;


            do {
                NumeroPersona = sc.nextFloat();
                sc.nextLine();
                if (NumeroPersona < 0 || NumeroPersona > 4) {
                    System.out.println("Te has pasado del rango, vuelve a probar");
                }
                intentos--;
                float restante = NumeroPersona - NumeroRandomF;
                System.out.println("Te quedan " + intentos + " intentos ");
                //Hacer que la diferencia sea siempre positiva
                if (restante < 0) {
                    restante = -(restante);
                }
                //.
                if (restante == 0) {
                    System.out.println("Tocadooo");
                    salir1 = true;
                    preguntas[4] = true;
                    ganador = "Ganasteeee";
                } else if (restante > 0 && restante <= 0.3f) {
                    System.out.println("Estas cerquita");
                } else if (restante > 0.3f && restante <= 1) {
                    System.out.println("Estas lejos");
                } else if (restante > 1) {
                    System.out.println("Estas demasiado lejos");
                }
                //Cuando se realizen los 10 intetnos se acaba el juego.
                if (intentos == 0) {
                    System.out.println("Gastaste los 10 intentos, prueba otra vez");
                    preguntas[4] = true;
                    salir1 = true;
                }

            } while (!salir1);
            System.out.println("Fin del juego");
            preguntas[4] = true;


        } else {
            System.out.println("Tienes que hacerme la pregunta anterior");
        }
       return ganador;
    }

    String nom(String s){
        if (preguntas[4] == true) {

            nombre = sc.next();



            System.out.println(nombre + ", gracias, me gusta este nombre");
            preguntas[5] = true;

        } else {
            System.out.println("Tienes que hacerme la pregunta anterior");
        }

        return nombre;
    }

    void printConversa(){
        if (preguntas[5] == true) {
            System.out.print("Mi nombre es ");
            System.out.print(nombre);
            System.out.print(" , soy un alien tipo ");
            System.out.print(tipo);
            System.out.print(" , me suelo desplazar con ");
            System.out.println(transporte);
        } else {
            System.out.println("Tienes que hacerme la pregunta anterior");
        }
    }
    void fiConversa(){
        if (salir2 = true);
    }
}

